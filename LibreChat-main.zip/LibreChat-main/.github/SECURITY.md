# Security Policy

At LibreChat, we prioritize the security of our project and value the contributions of security researchers in helping us improve the security of our codebase. If you discover a security vulnerability within our project, we appreciate your responsible disclosure. Please follow the guidelines below to report any vulnerabilities to us:

**Note: Only report sensitive vulnerability details via the appropriate private communication channels mentioned below. Public channels, such as GitHub issues and Discord, should be used for initiating contact and establishing private communication channels.**

## Communication Channels

When reporting a security vulnerability, you have the following options to reach out to us:

- **Option 1: GitHub Private Vulnerability Reporting**: Submit sensitive vulnerability details through LibreChat's [private vulnerability reporting form](https://github.com/LibreChat-AI/LibreChat/security/advisories/new). This sends the report confidentially to the project maintainers.

- **Option 2: GitHub Issues**: You can initiate first contact via GitHub Issues. However, please note that initial contact through GitHub Issues should not include any sensitive details.

- **Option 3: Discord Server**: You can join our [Discord community](https://discord.librechat.ai) and initiate first contact in the `#issues` channel. However, please ensure that initial contact through Discord does not include any sensitive details.

_After the initial contact, we will establish a private communication channel for further discussion._

### When submitting a vulnerability report, please provide us with the following information:

- A clear description of the vulnerability, including steps to reproduce it.
- The version(s) of the project affected by the vulnerability.
- Any additional information that may be useful for understanding and addressing the issue.

We strive to acknowledge vulnerability reports within 72 hours and will keep you informed of the progress towards resolution.

## Security Updates and Patching

We are committed to maintaining the security of our open-source project, LibreChat, and promptly addressing any identified vulnerabilities. To ensure the security of our project, we adhere to the following practices:

- We prioritize security updates for the current major release of our software.
- We actively monitor the GitHub Security Advisory system and the `#issues` channel on Discord for any vulnerability reports.
- We promptly review and validate reported vulnerabilities and take appropriate actions to address them.
- We release security patches and updates in a timely manner to mitigate any identified vulnerabilities.

Please note that as a security-conscious community, we may not always disclose detailed information about security issues until we have determined that doing so would not put our users or the project at risk. We appreciate your understanding and cooperation in these matters.

## Scope

This security policy applies to the following GitHub repository:

- Repository: [LibreChat](https://github.librechat.ai)

## Contact

If you have any questions or concerns regarding the security of our project, please join our [Discord community](https://discord.librechat.ai) and report them in the appropriate channel. You can also reach out to us by [opening an issue](https://github.com/LibreChat-AI/LibreChat/issues/new) on GitHub. Please note that the response time may vary depending on the nature and severity of the inquiry.

## Acknowledgments

We would like to express our gratitude to the security researchers and community members who help us improve the security of our project. Your contributions are invaluable, and we sincerely appreciate your efforts.

## Bug Bounty Program

We currently do not have a bug bounty program in place. We do welcome security-related contributions, a proposed fix included, but the report comes first and it comes privately: disclose through one of the channels above so we can confirm the issue and agree on how the fix lands. Please do not open a public pull request, issue or discussion that describes a vulnerability, even with a patch attached, because the patch itself explains the attack to everyone reading it before users have a release to upgrade to. We believe in the power of collaboration to improve the security of our project and invite you to join us in making it more robust.

**Reference**

- https://cheatsheetseries.owasp.org/cheatsheets/Vulnerability_Disclosure_Cheat_Sheet.html

---

## [Go Back to ReadMe](../README.md)
